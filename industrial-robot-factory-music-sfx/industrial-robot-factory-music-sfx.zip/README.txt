﻿========================================================================

INDUSTRIAL ROBOT FACTORY: MUSIC & SFX (FREE EDITION)

Version: 1.0 

Author: CookieEfedu

Platform Compatibility: Full Compatibilty with all major Game Engines and Frameworks , including
GameMaker, Godot Engine , Unity , Unreal Engne , Construct 3 , Rpg Maker and Custom C++/SDL2 Setup

========================================================================


Thank you for downloading the Industrial Robot Factory Music & Sfx Free Edition! 
This Package contains Esscential Music and Sfx for 16-Bit Retro Action-Science Fiction Games.

For get Access to the Content Listed Bellow you Can Purchase the Pro Version On:
https://cookieefedu.itch.io/industrial-robot-factory-music-sfx

 -The Base Music plus 3 Variants in OGG Format: Fast,Slow/Dark and Acid/Danger
 -Musics Organizated by Integrated Tracks (Full,Intro,ThemeA,..) and Steams (Individual Tracks)
 -Seamless Loop Files for the ThemeA and ThemeB of Each Music (Both Integrated Tracks and Steams)
 -Variety of Sfx Organizated by Types in WAV and OGG Format:
     1-Doors: Unlock,Lock,Open and Close
     2-Electric Saw: Start, Stop,Loop Plus Fast Version
     3-Electric Spark
     4-Explosion:  Normal and Plasma
     5-Hit: Normal, Missile and Plasma Projectile hit plus a sound for Heavy Hit
     6-Liquids: Splash Sounds
     7-Machinery: Energy Reactor, Switchs On/Off and Crusher Machine Hit 
     8-Shoots: Normal, Missile and Plasma Projectile
     9-Steams: Normal and Large Version
	

------------------------------------------------------------------------

1. TRACK DETAILS & SPECIFICATIONS

------------------------------------------------------------------------

Track Details:
-Tempo: 120 bpm
-Key / Mode:C Phrygian Mode (C-Db-Eb-F-G-Ab-Bb)
-Time Signature:4/4
-Audio Format: MP3 (192 kbps)
-Samplerate/frequency :44.1 khz

Sfx Details:
 -Audio Format: WAV and OGG Vorbis(Quality 8 / 256 kbps) 
 -Samplerate/frequency :44.1 khz

------------------------------------------------------------------------------------------------------------------------------------------------------------------------

2.PACK STRUCTURE

---------------------------------------------------------------------------------------------------------------------------------------------------------------------

-Files Included: 
  
  -Industrial_Robot_Factory.mp3               -->Full Track Music File in MP3 Format
  -README.txt                                 --> This Documentation File
  -lICENSE.txt                                -->License Information
  📁 Sfx/           ----> Sfx files 
     ├── 📁 ogg/                  ----> Sfx Files in OGG Format 
     └── 📁 wav/                  ----> Sfx Files in WAV Format
         

------------------------------------------------------------------------

3. CONTENT PACK LIST 

------------------------------------------------------------------------

Music Contain:

  -Tracks: Contains the Integrated Tracks:
        -Full Track: The Complete Track 
	-Full_Track_with_Tail (Only Pro): the Complete Track with a Tail/FadeOut at the end
	-Only_Intro (Only Pro): the Intro
        -Only_Transition_ThemeB (Only Pro): Transition Section from ThemeA to Theme B 
        -ThemeA_Loop (Only Pro): Loop of the Theme A 
	-ThemeB_Loop (Only Pro): Loop of theme B  
	-ThemeA+ThemeB_Loop (Only Pro): the Main Loop with:
             1- Theme A 
             2- Transition of Theme B 
             3- Theme B
	
  
  -Steams (Only Pro): Contains  Each Individual Track of the Musis. In the Name of File is Indicated
    the Section/ Rol and the Instrument/Sample. For Example:
	-Bass_Loop:Loop of the bass for both Theme A and Theme B Tracks
	-Intro_Battery: Battery for the Intro
	-ThemeA_Guitar: Guitar for the Theme A
        -ThemeB_Square_Wave:Square_Wave for the Theme B
	-Transition_ThemeB_Battery:Battery for the Transition to Theme B
 

SFX Contains:

   -Contain Two Folders One for Sfx in WAV Format (wav folder) and another in OGG format (ogg folder). 
   -In the Name of each File is Indicated the recomended use for the Sfx

  

------------------------------------------------------------------------

3. MUSIC VARIATIONS
------------------------------------------------------------------------

   -Base Version: the Base Version of the Music  
   -Hot Variation(Only Pro): the Fast Variation 
   -Night Variation(Only Pro): the Slow/Dark Variation 
   -Acid Variation(Only Pro): the Danger Variation

------------------------------------------------------------------------

4. SFX CATEGORIES 

------------------------------------------------------------------------

1- Doors: Sounds For Open, Close (Update to Pro for access to  Unlock ,Lock Sounds)
2- Electric Saw: Loop Sound (Update to Pro for Access to  Start, Stop  and  Fast Sounds)
3- Shoots: Sound for Trigger a Normal Shoot (Update to Pro for Access Plasma and Missile Shoot Sounds)
4- Electric Spark: Sound for Electric Sparks
5- Hit: Sounds for Normal Hit (Update to Pro for Access to Heavy, Plasma, Missile Hit Sounds)
6- Steam (Only Pro): Sounds for Steams
7- Liquids (Only Pro): Sounds for Splash On Liquids 
8- Machinery: Sounds for Switchs On/Off (Update to Pro for access to Crusher Machine Hit and Loop of Energy Engine Sounds)
9- Explosion (Only Pro): Sounds for Explosions (Normal, Largue and Plasma)
 
------------------------------------------------------------------------

5.TECHNICAL NOTES FOR PROGRAMMERS (Implementation Tips)

------------------------------------------------------------------------


- Damage Enemy: Play First a Hit Sound and After the Electric Spark Sound

- Electric Saw:
   Adjust Volumen by the distance with the Player

-Use the Switch On/Off Sound for Switchs or Toggles Activation/Desactivation

  
------------------------------------------------------------------------

6. SOUNDFONTS & SAMPLES CREDITS

------------------------------------------------------------------------

   Sounds Fonts :

    -GeneraUserGs Guitar Sound Font by Christian Collins (https://www.schristiancollins.com)
    -Super Nes Sound Fonts Gallery by William Kage (https://www.williamkage.com)
  
   Audio Samples by: 
     Kenney (https://kenney.nl)
     rubberduck (https://opengameart.org/users/rubberduck)
     Iwan 'qubodup' Gabovitch (https://opengameart.org/users/qubodup)

------------------------------------------------------------------------

7. QUICK LICENSE SUMMARY

------------------------------------------------------------------------

 This Asset Pack is Licensed Under Creative Commons Attribution 4.0 Internacional (CC-BY 4.0)

 You are Free to:
   -Use These Asset in Commercial and Non-Commercial Games, Interactive Projects and Media
   -Modify,Edit,Chop or Pitch Shift the Asset to Fit your Project

 Requeriments:
   -Attribution/ Credit: Requerid

 How To Credit:
  Music & Sfx by CookieEfedu ( https://cookieefedu.itch.io)

========================================================================
To get the Full Version of the Pack, you can Purchase it Here:
  https://cookieefedu.itch.io/industrial-robot-factory-music-sfx

For support or feedback: 
 Contact Email: cookieefedu.gamedev@gmail.com 
 Art Portafolio:https://www.deviantart.com/cookieefedu
 Music Portafolio:https://soundcloud.com/cookieefedu
 Social/ Updates: https://instagram.com/cookie_efedu (@cookie_efedu)

Enjoy making your game!

===============================================================