#!/usr/bin/env python3
"""Render the WebAudio synthesis recipes from gamedemo_by_Fable5.2 src/core/audio.ts
to OGG files, offline. Deterministic (seeded). Stdlib + ffmpeg only.

Original code: https://github.com/weit0529/gamedemo_by_Fable5.2 (MIT, (c) 2026 weit0529)
This renderer re-implements the same oscillator/envelope/biquad math so the sounds
can be used outside the browser.
"""
import math, os, random, struct, subprocess, sys, wave

FS = 44100
MASTER = 0.5  # Sfx.volume default
rng = random.Random(20261120)

def _ramp(v0, v1, t0, t1, t):
    if t <= t0: return v0
    if t >= t1: return v1
    return v0 * (v1 / v0) ** ((t - t0) / (t1 - t0))

def _osc(kind, phase):
    if kind == 'sine': return math.sin(phase)
    if kind == 'square': return 1.0 if math.sin(phase) >= 0 else -1.0
    if kind == 'sawtooth':
        x = (phase / (2 * math.pi)) % 1.0
        return 2.0 * x - 1.0
    if kind == 'triangle':
        return (2.0 / math.pi) * math.asin(math.sin(phase))
    raise ValueError(kind)

def tone(buf, freq, dur, type='sine', to=None, vol=0.2, delay=0.0):
    start = int(delay * FS); n = int((dur + 0.02) * FS)
    phase = 0.0; prev_f = freq
    for i in range(n):
        t = i / FS
        if t > dur: f = to if to else freq
        else: f = _ramp(freq, to, 0.0, dur, t) if to else freq
        # phase integrates frequency; approximate per-sample with average of prev/cur
        phase += 2 * math.pi * (prev_f + f) * 0.5 / FS
        prev_f = f
        if t < 0.01: g = _ramp(0.0001, vol, 0.0, 0.01, t)
        else: g = _ramp(vol, 0.0001, 0.01, dur, t)
        idx = start + i
        if idx < len(buf): buf[idx] += MASTER * g * _osc(type, phase)

class Biquad:
    def __init__(self, kind, q):
        self.kind = kind; self.q = q
        self.x1 = self.x2 = self.y1 = self.y2 = 0.0
        self.set(1200.0)
    def set(self, f):
        f = max(20.0, min(f, FS * 0.45))
        w0 = 2 * math.pi * f / FS; a = math.sin(w0) / (2 * self.q); cw = math.cos(w0)
        if self.kind == 'lowpass':
            b0 = (1 - cw) / 2; b1 = 1 - cw; b2 = (1 - cw) / 2
        else:  # bandpass, constant 0 dB peak gain
            b0 = a; b1 = 0.0; b2 = -a
        a0 = 1 + a; a1 = -2 * cw; a2 = 1 - a
        self.b0, self.b1, self.b2 = b0 / a0, b1 / a0, b2 / a0
        self.a1, self.a2 = a1 / a0, a2 / a0
    def run(self, x):
        y = self.b0 * x + self.b1 * self.x1 + self.b2 * self.x2 - self.a1 * self.y1 - self.a2 * self.y2
        self.x2, self.x1 = self.x1, x; self.y2, self.y1 = self.y1, y
        return y

def hiss(buf, dur, freq=1200.0, to=None, q=1.0, vol=0.2, type='bandpass', delay=0.0):
    start = int(delay * FS); n = int((dur + 0.02) * FS)
    bp = Biquad(type, q)
    off = rng.random() * 0.5  # matches src.start(t, Math.random()*0.5)
    for i in range(n):
        t = i / FS
        f = _ramp(freq, to, 0.0, dur, t) if (to and t <= dur) else (to if to else freq)
        bp.set(f)
        x = rng.random() * 2 - 1
        if t < 0.012: g = _ramp(0.0001, vol, 0.0, 0.012, t)
        else: g = _ramp(vol, 0.0001, 0.012, dur, t)
        idx = start + i
        if idx < len(buf): buf[idx] += MASTER * g * bp.run(x)

def render(name, total_dur, fn):
    buf = [0.0] * int((total_dur + 0.1) * FS)
    fn(buf)
    peak = max(abs(v) for v in buf) or 1.0
    os.makedirs('wav', exist_ok=True)
    path = f'wav/{name}.wav'
    with wave.open(path, 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(FS)
        w.writeframes(b''.join(struct.pack('<h', int(max(-1, min(1, v)) * 32767)) for v in buf))
    return path, peak

SOUNDS = {
    'swing':       (0.3,  lambda b: hiss(b, 0.16, freq=900, to=3200, q=0.8, vol=0.14)),
    'swing_heavy': (0.4,  lambda b: hiss(b, 0.26, freq=500, to=1800, q=0.8, vol=0.22)),
    'cast':        (0.35, lambda b: (tone(b, 520, 0.18, type='triangle', to=1040, vol=0.1), hiss(b, 0.14, freq=2600, vol=0.05))),
    'hit':         (0.25, lambda b: (hiss(b, 0.09, freq=1500, q=0.6, vol=0.28), tone(b, 170, 0.1, type='square', to=60, vol=0.12))),
    'hit_heavy':   (0.25, lambda b: (hiss(b, 0.09, freq=600, q=0.6, vol=0.28), tone(b, 110, 0.1, type='square', to=60, vol=0.12))),
    'crit':        (0.3,  lambda b: (hiss(b, 0.09, freq=600, q=0.6, vol=0.28), tone(b, 110, 0.1, type='square', to=60, vol=0.12), tone(b, 1400, 0.12, type='triangle', to=2200, vol=0.09))),
    'react':       (0.45, lambda b: (tone(b, 660, 0.25, type='sawtooth', to=1320, vol=0.08), hiss(b, 0.3, freq=3000, to=500, vol=0.14))),
    'boom':        (0.65, lambda b: (hiss(b, 0.5, freq=900, to=90, q=0.4, vol=0.4, type='lowpass'), tone(b, 90, 0.4, to=35, vol=0.3))),
    'dodge':       (0.35, lambda b: hiss(b, 0.2, freq=700, to=2600, q=0.7, vol=0.16)),
    'perfect':     (0.5,  lambda b: (tone(b, 880, 0.3, type='triangle', to=1760, vol=0.14), tone(b, 1320, 0.3, type='sine', to=2640, vol=0.08, delay=0.05))),
    'jump':        (0.25, lambda b: tone(b, 280, 0.12, type='triangle', to=460, vol=0.07)),
    'land':        (0.25, lambda b: hiss(b, 0.1, freq=300, q=0.5, vol=0.18, type='lowpass')),
    'step':        (0.2,  lambda b: hiss(b, 0.05, freq=500 + rng.random() * 300, q=0.6, vol=0.05, type='lowpass')),
    'hurt':        (0.35, lambda b: tone(b, 220, 0.2, type='sawtooth', to=110, vol=0.14)),
    'pick':        (0.35, lambda b: (tone(b, 880, 0.1, type='triangle', vol=0.1), tone(b, 1320, 0.14, type='triangle', vol=0.1, delay=0.07))),
    'chest':       (0.7,  lambda b: [tone(b, f, 0.22, type='triangle', vol=0.11, delay=i * 0.08) for i, f in enumerate([523, 659, 784, 1047])]),
    'waypoint':    (1.0,  lambda b: [tone(b, f, 0.5, type='sine', vol=0.12, delay=i * 0.1) for i, f in enumerate([392, 587, 784, 1175])]),
    'levelup':     (0.8,  lambda b: [tone(b, f, 0.3, type='triangle', vol=0.12, delay=i * 0.07) for i, f in enumerate([523, 659, 784, 1047, 1319])]),
    'swap':        (0.25, lambda b: tone(b, 700, 0.1, type='sine', to=1100, vol=0.09)),
    'glide':       (0.5,  lambda b: hiss(b, 0.35, freq=400, to=1400, q=0.5, vol=0.12)),
    'splash':      (0.55, lambda b: hiss(b, 0.4, freq=1800, to=400, q=0.5, vol=0.2)),
    'ui':          (0.2,  lambda b: tone(b, 900, 0.06, type='triangle', vol=0.06)),
    'deny':        (0.25, lambda b: tone(b, 200, 0.12, type='square', vol=0.06)),
}

def main():
    outdir = sys.argv[1] if len(sys.argv) > 1 else 'sfx'
    os.makedirs(outdir, exist_ok=True)
    for name, (dur, fn) in SOUNDS.items():
        wavpath, peak = render(name, dur, fn)
        subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', wavpath, '-c:a', 'libvorbis', '-q:a', '5', f'{outdir}/{name}.ogg'], check=True)
        print(f'{name}.ogg peak={peak:.3f}')

if __name__ == '__main__':
    main()
