POCKET BLEEPS - FREE SAMPLER: 31 RETRO 8-BIT SFX
Created by Pocket Bleeps.

31 original chiptune sound effects, one from each category of the full pack:
jump, coin, power-up, laser, explosion, hit, hurt, death, extra life, UI move/
confirm/cancel/error/select, text blip, footstep, door, teleport, alarm,
charge-up, dash, bounce, magic, shield, throw, water splash, engine rumble,
and victory / game over / item get / level start jingles.

Format: 44.1 kHz 16-bit mono WAV, loudness-matched and click-free.
License: CC BY 4.0 - credit "Sound effects by Pocket Bleeps". See LICENSE.txt.

WANT MORE? The full pack has 372 sounds (12 variations per category), WAV + OGG,
drop-in Godot 4 and Unity scripts, and the generator source:
https://chipforgeaudio.itch.io/chipforge-372-retro-8-bit-sfx-wavogg-godot-unity-scripts-generator
